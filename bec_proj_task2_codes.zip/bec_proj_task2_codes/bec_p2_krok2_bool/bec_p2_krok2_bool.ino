#define BUTTON_PIN 5

bool led_state=LOW;

void setup() {
 pinMode(LED_BUILTIN,OUTPUT);
 pinMode(BUTTON_PIN,INPUT_PULLUP); }

void loop() {
 if(button_pressed(BUTTON_PIN)) {
  led_state = !led_state;
  digitalWrite(LED_BUILTIN,led_state);
 }
 delay(100);
}

bool button_pressed(int button_pin) {
 if(digitalRead(button_pin) == LOW) {
  delay(100);
  while(digitalRead(button_pin) == LOW);
  return true;
 }
 else
  return false;
}
