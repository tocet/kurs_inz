#include <Wire.h>
#include <LiquidCrystal_PCF8574.h>

#define BAUDRATE 115200

// ustaw adres sterownika LCD na 0x27
LiquidCrystal_PCF8574 lcd(0x27);  
int show;

void setup() {
int error;

Serial.begin(BAUDRATE);
Serial.println("LCD...");

Wire.begin();
Wire.beginTransmission(0x27);
error = Wire.endTransmission();
Serial.print("Error: ");
Serial.println(error);
if (error == 0) 
  Serial.println("LCD found.");
 else {
  Serial.println("LCD not found.");
  while(1);
}

// inicjalizacja sterownika
lcd.begin(16, 2); 
} 

String lcd_line1 = "Tekst w linii 1";
String lcd_line2 = "Tekst w linii 2";

void loop() {
lcd.print(lcd_line1);
lcd.setCursor(0,1);
lcd.print(lcd_line2);
digitalWrite(LED_BUILTIN,HIGH);
delay(4000);

int liczba = 5;
lcd.setCursor(0,1);
lcd_line2 = "Liczba = " + String(liczba);
lcd.print(lcd_line2);
}
