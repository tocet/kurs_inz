#define BAUDRATE 115200

unsigned long timer;
unsigned long p_timer = 0;

void setup() {
 Serial.begin(BAUDRATE);
 Serial.println(timer); }

void loop() {
 timer = millis();
 if(timer - p_timer >= 2000) {
 Serial.println(timer); 
 p_timer = timer;
 }
 }
