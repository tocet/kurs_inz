#include <Wire.h>
#include <LiquidCrystal_PCF8574.h>

#define BAUDRATE 115200

// ustaw adres sterownika LCD na 0x27
LiquidCrystal_PCF8574 lcd(0x27);  
int show;

void setup()
{
int error;

Serial.begin(BAUDRATE);
Serial.println("LCD...");

Wire.begin();
Wire.beginTransmission(0x27);
error = Wire.endTransmission();
Serial.print("Error: ");
Serial.println(error);
if (error == 0) 
  Serial.println("LCD found.");
 else {
  Serial.println("LCD not found.");
  while(1);
}

// inicjalizacja sterownika
lcd.begin(16, 2); 
} 

void loop()
{
lcd.print("Hello!!!");
while(1) {
  digitalWrite(LED_BUILTIN,HIGH);
  delay(250);
  digitalWrite(LED_BUILTIN,LOW);
  delay(250);
}
} 
