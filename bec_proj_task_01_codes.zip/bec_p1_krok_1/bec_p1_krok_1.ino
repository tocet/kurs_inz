#define BAUDRATE 115200
#define BUTTON1_PIN 5
int buttonstate;

void setup() {
  pinMode(BUTTON1_PIN,INPUT_PULLUP);
  Serial.begin(BAUDRATE);
}

void loop() {
  buttonstate = digitalRead(BUTTON1_PIN);
  if(buttonstate == LOW)
  Serial.println("Button is down");
  else
  Serial.println("Button is up");
  delay(250);
}
