#define BAUDRATE 115200
#define TriggerPin 3
#define EchoPin 2

#define pinR 9
#define pinG 10
#define pinB 11

#define DISTANCE_MIN 10           // [cm]
#define DISTANCE_MAX 30           // [cm]

#if DISTANCE_MIN < 0 || DISTANCE_MIN >= DISTANCE_MAX
#error "Zakres musi spelniac: 0 <= DISTANCE_MIN < DISTANCE_MAX"

#endif

void setup() {
  Serial.begin(BAUDRATE);

  pinMode(TriggerPin, OUTPUT);
  pinMode(EchoPin, INPUT);

  pinMode(pinR, OUTPUT);
  pinMode(pinG, OUTPUT);
  pinMode(pinB, OUTPUT);

  digitalWrite(TriggerPin, LOW);
  setRGB(0, 0, 0);
}

void loop() {
  float distance = hcsr04_measurement(TriggerPin, EchoPin);

  if (distance < 0) {
    setRGB(0, 0, 0);
    Serial.println("Brak echa | RGB: OFF");
  } else {
    Serial.print("Distance: ");
    Serial.print(distance, 1);
    Serial.print(" [cm]");

    if (distance < DISTANCE_MIN || distance > DISTANCE_MAX) {
      setRGB(0, 0, 0);
      Serial.println(" | Poza zakresem | RGB: OFF");
    } else {
      long distanceMm = (long)(distance * 10.0f + 0.5f);

      // Najbliżej: poziom 6. Najdalej: poziom 0.
      int level = (int)map(
      distanceMm,
      DISTANCE_MIN * 10L,
      DISTANCE_MAX * 10L,
      7,
      0
      );

      // Wartosc 7 przy dolnej granicy należy do poziomu 6.
      level = constrain(level, 0, 6);

      switch (level) {
        case 0:
        setRGB(255, 255, 0);             // yellow
        break;

        case 1:
        setRGB(255, 212, 0);
        break;

        case 2:
        setRGB(255, 170, 0);
        break;

        case 3:
        setRGB(255, 128, 0);             //orange
        break;

        case 4:
        setRGB(255, 85, 0);
        break;

        case 5:
        setRGB(255, 42, 0);
        break;

        case 6:
        setRGB(255, 0, 0);               // red
        break;
      }

      Serial.print(" | Poziom koloru: ");
      Serial.println(level);
    }
  }

  delay(500);
}

float hcsr04_measurement(int T_Pin, int E_Pin) {
  digitalWrite(T_Pin, LOW);
  delayMicroseconds(2);
  digitalWrite(T_Pin, HIGH);
  delayMicroseconds(10);
  digitalWrite(T_Pin, LOW);

  unsigned long duration = pulseIn(E_Pin, HIGH, 30000UL);

  if (duration == 0) {
    return -1;
  }

  return duration / 58.2f;
}

void setRGB(int red, int green, int blue) {
  analogWrite(pinR, red);
  analogWrite(pinG, green);
  analogWrite(pinB, blue);
}
