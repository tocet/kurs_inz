#define BAUDRATE 115200
#define TriggerPin 3
#define EchoPin 2

#define DISTANCE_MIN 10           // [cm]
#define DISTANCE_MAX 30           // [cm]

float response;

void setup() {
  Serial.begin(BAUDRATE);

  pinMode(TriggerPin, OUTPUT);
  pinMode(EchoPin, INPUT);
  pinMode(LED_BUILTIN, OUTPUT);

  digitalWrite(TriggerPin, LOW);
  digitalWrite(LED_BUILTIN, LOW);
}

void loop() {
  response = hcsr04_measurement(TriggerPin, EchoPin);

  bool inRange = response >= 0 &&
  response >= DISTANCE_MIN &&
  response <= DISTANCE_MAX;

  digitalWrite(LED_BUILTIN, inRange ? HIGH : LOW);

  if (response < 0) {
    Serial.println("Brak echa | LED: OFF");
  } else {
    Serial.print("Distance: ");
    Serial.print(response, 1);
    Serial.print(" [cm] | LED: ");
    Serial.println(inRange ? "ON" : "OFF");
  }

  delay(500);
}

float hcsr04_measurement(int T_Pin, int E_Pin) {
  digitalWrite(T_Pin, LOW);
  delayMicroseconds(2);
  digitalWrite(T_Pin, HIGH);
  delayMicroseconds(10);
  digitalWrite(T_Pin, LOW);

  // Oczekiwanie na echo maksymalnie przez 30 ms.
  unsigned long duration = pulseIn(E_Pin, HIGH, 30000UL);

  if (duration == 0) {
    return -1;     // Brak poprawnego pomiaru.
  }

  return duration / 58.2f;
}
