#define pinR     9
#define pinG     10
#define pinB     11
#define BAUDRATE       115200

void setup() {
  pinMode(pinR,OUTPUT);
  pinMode(pinG,OUTPUT);
  pinMode(pinB,OUTPUT);

  digitalWrite(pinR,LOW);
  digitalWrite(pinG,LOW);
  digitalWrite(pinB,LOW);
}

void loop() {
  digitalWrite(pinR,HIGH);
  digitalWrite(pinG,LOW);
  digitalWrite(pinB,LOW);
  delay(2000);
  digitalWrite(pinR,LOW);
  digitalWrite(pinG,HIGH);
  digitalWrite(pinB,LOW);
  delay(2000);

  digitalWrite(pinR,LOW);
  digitalWrite(pinG,LOW);
  digitalWrite(pinB,HIGH);
  delay(2000);
}

/*
Przyklady dodatkowe z kroku 5 (do zastosowania w loop()):

// Czerwony + zielony = zolty.
digitalWrite(pinR, HIGH);
digitalWrite(pinG, HIGH);
digitalWrite(pinB, LOW);

// Swiatlo biale.
digitalWrite(pinR, HIGH);
digitalWrite(pinG, HIGH);
digitalWrite(pinB, HIGH);
*/
