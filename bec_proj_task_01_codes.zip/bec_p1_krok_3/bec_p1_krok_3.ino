#define BAUDRATE 115200
#define TRIGGER_PIN         3
#define ECHO_PIN            2

long response;

void setup() {
  Serial.begin(BAUDRATE);
  pinMode(TRIGGER_PIN,OUTPUT);
  pinMode(ECHO_PIN,INPUT_PULLUP);
}

void loop() {
  response = hcsr04_measurement(TRIGGER_PIN,ECHO_PIN);

  Serial.print("Distance: ");
  Serial.print(response);
  Serial.println("[cm]");

  delay(500);
}

long hcsr04_measurement(int T_Pin, int E_Pin) {
  digitalWrite(T_Pin,LOW);
  delayMicroseconds(2);
  digitalWrite(T_Pin,HIGH);
  delayMicroseconds(10);
  digitalWrite(T_Pin,LOW);
  return pulseIn(E_Pin,HIGH)/58.2;
}
